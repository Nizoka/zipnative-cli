interop corpus — plain ASCII text
